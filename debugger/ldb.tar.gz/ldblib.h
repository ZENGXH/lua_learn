
#line 275 "ldb.nw"
#define LDB_REVISION	"$Revision: 1.12 $\b"
#define LDB_VERSION	"Ldb 1.1"
#define LDB_AUTHORS	"T. G. Gorham & R. Ierusalimschy"
void ldblib_open (void);
